#### Importing properties from other modules ########

######################################################