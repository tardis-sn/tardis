# Generated file; do not modify
cython_version = '0.29.6'
