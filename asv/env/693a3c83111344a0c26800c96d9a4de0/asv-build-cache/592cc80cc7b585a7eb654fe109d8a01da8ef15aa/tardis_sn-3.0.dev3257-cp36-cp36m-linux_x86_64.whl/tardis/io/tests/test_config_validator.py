# TODO: Write tests for the new validator
pass
