"""
Calculating transition probabilities for macro_atom interactions.
"""
