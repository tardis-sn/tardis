"""
Storing a grid of TARDIS parameters that 
facilitates running large numbers of 
simulations easily.
"""

from tardis.grid.base import *
