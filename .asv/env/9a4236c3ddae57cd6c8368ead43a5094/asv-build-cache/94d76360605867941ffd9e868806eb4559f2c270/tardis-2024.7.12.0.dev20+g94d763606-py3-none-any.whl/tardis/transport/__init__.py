"""
Handling the packet propagation.
"""
