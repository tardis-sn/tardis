"""
Jupyter widgets to interactively explore TARDIS simulations.

These are simple Graphical User Interfaces (GUIs) that run within Jupyter
Notebooks, making data exploration much easier.
"""
