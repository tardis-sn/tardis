"""
Providing Poisson statistics that govern the MonteCarlo processes.
"""
