from tardis import run_tardis

yaml_file = "tardis_example_single.yml"

mdl = run_tardis(yaml_file)
