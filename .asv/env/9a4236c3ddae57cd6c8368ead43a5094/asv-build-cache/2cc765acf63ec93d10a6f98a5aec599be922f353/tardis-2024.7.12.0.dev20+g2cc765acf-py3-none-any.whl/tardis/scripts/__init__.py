"""
Translate cmfgen format to a format TARDIS can use.
"""
