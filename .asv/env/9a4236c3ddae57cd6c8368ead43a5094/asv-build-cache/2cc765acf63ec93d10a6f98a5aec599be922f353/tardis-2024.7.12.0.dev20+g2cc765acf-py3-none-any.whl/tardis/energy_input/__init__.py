"""
Contains classes and functions to handle energy deposition and transport.
"""
