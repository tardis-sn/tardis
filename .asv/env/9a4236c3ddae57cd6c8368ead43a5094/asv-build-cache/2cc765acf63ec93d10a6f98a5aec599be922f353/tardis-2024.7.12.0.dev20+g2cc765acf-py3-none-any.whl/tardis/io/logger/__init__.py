"""
Managing the logging output. 
"""
