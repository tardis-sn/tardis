"""
A collection of subpackages and submodules to handle input and output data.
"""
