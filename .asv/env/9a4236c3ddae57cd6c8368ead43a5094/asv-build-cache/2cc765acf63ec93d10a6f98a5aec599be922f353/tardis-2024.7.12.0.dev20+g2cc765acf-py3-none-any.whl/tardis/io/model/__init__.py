from tardis.io.model.readers.stella import read_stella_model

# from tardis.io.model.stella import read_stella_model
from tardis.io.model.readers.cmfgen import read_cmfgen_model
