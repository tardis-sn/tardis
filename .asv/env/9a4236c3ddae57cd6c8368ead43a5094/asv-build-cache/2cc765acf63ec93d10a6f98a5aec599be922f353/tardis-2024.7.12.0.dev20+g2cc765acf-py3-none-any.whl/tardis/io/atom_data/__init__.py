"""
Getting and handling the atomic data. 
"""

from tardis.io.atom_data.base import AtomData
from tardis.io.atom_data.atom_web_download import download_atom_data
